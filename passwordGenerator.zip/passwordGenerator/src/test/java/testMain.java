/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import characters.capitalLetters;
import characters.numbers;
import characters.smallLetters;
import characters.specialCharacters;
import config.cfg;
import randomIntegers.randInt10;
import randomIntegers.randInt26;
import create.createPw;
import timers.onDelayTimer;
import java.util.Date;
/**
 *
 * @author ett15289
 */
public class testMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /**
        
        randomIntegers.randInt26 rnd26 = new randomIntegers.randInt26();
        rnd26.getLengths(true);
        rnd26.swapWithRuleset(0);
        rnd26.getLengths(true);
        */
             
        String[] myPw = new String[10];
        String myString = "Tapio";
        create.createPw create = new create.createPw();
        //myPw[0] = create.createSinglePw(0, myString);
        //create.rnd10.swapWithRuleset(1);
        //create.rnd26.swapWithRuleset(1);
        myPw[1] = create.createSinglePw(1, myString);
        myPw[2] = create.createSinglePw(2, myString);
        myPw[3] = create.createSinglePw(3, myString);
        //myPw[4] = create.createSinglePw(4, myString);
        //myPw[5] = create.createSinglePw(5, myString);
        //myPw[6] = create.createSinglePw(6, myString);
        //myPw[7] = create.createSinglePw(7, myString);
        //myPw[8] = create.createSinglePw(8, myString);
        //myPw[9] = create.createSinglePw(9, myString);
        
        
        //System.out.println(myPw[0]);
        //System.out.println(myPw[1]);
        //System.out.println(myPw[2]);
        //System.out.println(myPw[3]);
        //System.out.println(myPw[4]);
        //System.out.println(myPw[5]);
        //System.out.println(myPw[6]);
        //System.out.println(myPw[7]);
        //System.out.println(myPw[8]);
        //System.out.println(myPw[9]);
        //timers.onDelayTimer odt = new timers.onDelayTimer(10000);
        //System.out.println("Hi");
        //Date ms = new Date();
        //long thisTime = ms.getTime();
        //System.out.println(thisTime);
        characters.capitalLetters caps = new characters.capitalLetters();
        String temp = caps.retString(39);
        System.out.println(temp);
}
}
