/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;
import java.io.*;
import java.util.Properties;

/**
 *
 * @author ett15289
 */
public class cfg {
    public int pwCount;
    public int pwLen;
    public int maxLen;
    public String[] alias = new String[10];
    public String format;
    public String formatSpcChars;
    public String createPw;
    public boolean includeSpcChars;
    public int loopCount;
      
    
    public cfg(){
        //String cfgFilePath = "src/cfg.properties";
        File configFile = new File("src/cfg.properties");
        try {
        FileReader reader = new FileReader(configFile);
        Properties props = new Properties();
        props.load(reader); 
        this.alias[0] = props.getProperty("DB_ALIAS_1");
        this.alias[1] = props.getProperty("DB_ALIAS_2");
        this.alias[2] = props.getProperty("DB_ALIAS_3");
        this.alias[3] = props.getProperty("DB_ALIAS_4");
        this.alias[4] = props.getProperty("DB_ALIAS_5");
        this.alias[5] = props.getProperty("DB_ALIAS_6");
        this.alias[6] = props.getProperty("DB_ALIAS_7");
        this.alias[7] = props.getProperty("DB_ALIAS_8");
        this.alias[8] = props.getProperty("DB_ALIAS_9");
        this.alias[9] = props.getProperty("DB_ALIAS_10");
        
        reader.close();
        } catch (FileNotFoundException ex) {
            System.out.println("He");
        // file does not exist
        } catch (IOException ex) {
        // I/O error
        System.out.println("Ha");
        }

        this.pwCount = 10;
        this.format = "Aa0a0aA0A0a0AaAa00A0A0a0A0Aaa0A0Aaa0";
        this.formatSpcChars = "=a0a0aA0A=A0AaAa0=A0A0a0A0=aa0A0Aaa0";
        this.maxLen = 24;
        this.pwLen = 8;
        this.createPw = "JohnnyB";
        this.loopCount = 10;
        this.includeSpcChars = false;
    } 
}
