/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package randomIntegers;

/**
 *
 * @author ett15289
 */
public class randInt10 {
    public int[][] val = new int[10][];
    public int lenVal0;
    public int[] lenVal1 = new int[10];
    public int[][][] swapRuleset = new int[10][][];
    public int lenRuleset0;
    public int[] lenRuleset1 = new int[10];
    public int[][] lenRuleset2 = new int[10][10];
    
    public randInt10(){
        int[] _0 = {6, 6, 8, 6, 1, 1, 1, 9, 9, 0};
        int[] _1 = {4, 1, 0, 6, 2, 6, 1, 9, 5, 0};
        int[] _2 = {7, 7, 5, 5, 5, 8, 6, 6, 1, 1};
        int[] _3 = {6, 3, 9, 0, 3, 4, 9, 8, 2, 1};
        int[] _4 = {5, 4, 6, 1, 9, 1, 9, 6, 9, 5};
        int[] _5 = {9, 7, 6, 0, 4, 3, 2, 2, 7, 4};
        int[] _6 = {0, 4, 9, 4, 3, 4, 7, 8, 6, 6};
        int[] _7 = {9, 8, 3, 8, 5, 3, 7, 5, 8, 3};
        int[] _8 = {3, 6, 7, 2, 6, 5, 1, 3, 0, 3};
        int[] _9 = {3, 2, 9, 0, 6, 1, 9, 7, 2, 2};
        int[][] ruleset0 = {{0, 3}, {1, 9}, {4, 5}, {1, 4}, {2, 3}, {9, 6}, {1, 5}, {8, 9}, {8, 4}, {5, 3}};
        int[][] ruleset1 = {{6, 5}, {3, 2}, {9, 5}, {5, 8}, {1, 2}, {3, 2}, {8, 9}, {1, 2}, {1, 9}, {0, 9}};
        int[][] ruleset2 = {{2, 3}, {2, 4}, {6, 4}, {6, 3}, {9, 6}, {5, 3}, {5, 0}, {9, 7}, {6, 4}, {2, 9}};
        int[][] ruleset3 = {{8, 5}, {8, 1}, {0, 4}, {7, 1}, {6, 8}, {2, 9}, {1, 0}, {8, 0}, {9, 6}, {3, 9}};
        int[][] ruleset4 = {{9, 9}, {8, 9}, {3, 2}, {9, 6}, {0, 5}, {6, 3}, {0, 3}, {0, 8}, {1, 0}, {4, 0}};
        int[][] ruleset5 = {{4, 8}, {4, 5}, {2, 6}, {5, 4}, {2, 1}, {5, 8}, {1, 7}, {7, 0}, {7, 5}, {0, 7}};
        int[][] ruleset6 = {{5, 3}, {2, 2}, {3, 5}, {6, 5}, {8, 8}, {7, 1}, {7, 2}, {8, 7}, {8, 7}, {7, 9}};
        int[][] ruleset7 = {{1, 0}, {9, 8}, {7, 8}, {5, 6}, {7, 8}, {1, 7}, {9, 0}, {3, 9}, {0, 1}, {0, 6}};
        int[][] ruleset8 = {{6, 8}, {7, 9}, {6, 2}, {7, 9}, {5, 0}, {4, 7}, {6, 1}, {7, 2}, {2, 8}, {3, 9}};
        int[][] ruleset9 = {{5, 1}, {7, 2}, {0, 9}, {5, 7}, {5, 9}, {1, 9}, {4, 1}, {7, 6}, {8, 4}, {3, 0}};
        this.val[0] = _0;
        this.val[1] = _1;
        this.val[2] = _2;
        this.val[3] = _3;
        this.val[4] = _4;
        this.val[5] = _5;
        this.val[6] = _6;
        this.val[7] = _7;
        this.val[8] = _8;
        this.val[9] = _9;
        this.swapRuleset[0] = ruleset0;
        this.swapRuleset[1] = ruleset1;
        this.swapRuleset[2] = ruleset2;
        this.swapRuleset[3] = ruleset3;
        this.swapRuleset[4] = ruleset4;
        this.swapRuleset[5] = ruleset5;
        this.swapRuleset[6] = ruleset6;
        this.swapRuleset[7] = ruleset7;
        this.swapRuleset[8] = ruleset8;
        this.swapRuleset[9] = ruleset9;
        this.getLengths(false);
    }
    
    public void getLengths(boolean in_cmdPrint){
        int i;
        int k;
        String tempStr = "";
        // value matrix lengths
        // value matrix length level 0        
        this.lenVal0 = this.val.length;
        // value matrix length level 1
        for (i = 0; i<=9; i++){
            this.lenVal1[i] = this.val[i].length;
        }
        // swap ruleset matrix lengths
        // swap ruleset matrix length level 0
        this.lenRuleset0 = this.swapRuleset.length;
        // swap ruleset matrix length level 1
        for(i = 0; i<=9; i++){
            this.lenRuleset1[i] = this.swapRuleset[i].length;
        }
        // swap ruleset matrix length level 2
        for(i = 0; i<=9; i++){
            for(k = 0; k<=9; k++){
                this.lenRuleset2[i][k] = this.swapRuleset[i][k].length;
            }            
        }
        if(in_cmdPrint == true){
            System.out.println("lenVal 0: " + this.lenVal0);
            for(i = 0; i<=9; i++){
                tempStr = tempStr + String.valueOf(this.lenVal1[i]) + " ";
            }
            System.out.println("lenVal 1: " + tempStr);
            System.out.println("lenSwap 0: " + this.lenRuleset0);
            tempStr = "";
            for(i = 0; i<=9; i++){
                tempStr = tempStr + String.valueOf(this.lenRuleset1[i]) + " ";
            }
            System.out.println("lenSwap 1: " + tempStr);            
            for(i = 0; i<=9; i++){
                tempStr = "";
                for(k = 0; k<=9; k++){
                    tempStr = tempStr + String.valueOf(this.lenRuleset2[i][k]) + " ";
                }
                System.out.println("lenSwap 2 / " + i + ": " + tempStr);                
            }
        }
    }
    
    public void swapWithRuleset(int in_ruleSetNumber){
        int ruleSetNumber;
        int[] temp1 = new int[10];
        int[] temp2 = new int[10];
        int i;
        //this.printMatrix();
        System.out.println(" ");
        if (in_ruleSetNumber < 0 || in_ruleSetNumber > this.lenRuleset0-1){
            ruleSetNumber = 0;
        }
        else{
            ruleSetNumber = in_ruleSetNumber;
            for(i=0; i<this.lenRuleset1[in_ruleSetNumber]; i++){
                temp1 = this.val[this.swapRuleset[ruleSetNumber][i][0]];
                temp2 = this.val[this.swapRuleset[ruleSetNumber][i][1]];
                this.val[this.swapRuleset[ruleSetNumber][i][0]] = temp2;
                this.val[this.swapRuleset[ruleSetNumber][i][1]] = temp1;
            }
        }
        //this.printMatrix();
    }
    
    public int loopThroughValues(int in_row, int in_column, int in_loopCount){
        int loopCounter = 0;
        int[] coord = {0,0};
        while (loopCounter < in_loopCount){
            if(loopCounter == 0){
                coord[0] = in_row;
                coord[1] = in_column;
            }
            if(coord[0] > this.lenVal0 - 1 || coord[0] < 0){
                coord[0] = 0;
            }
            if(coord[1] > this.lenVal1[coord[0]] - 1 || coord[1] < 0){
                coord[1] = 0;
            }
            coord[1] = this.val[coord[0]][coord[1]];
            coord[0] += 1;
            loopCounter += 1;
        }
        return this.val[coord[0]][coord[1]];
    }
    
    public void printMatrix(){
        for(int i = 0; i< this.lenVal0; i++){
            String temp = "";
            for(int j = 0; j<this.lenVal1[i]; j++){
                temp = temp + this.val[i][j] + " ";
            }
            System.out.println(temp);
        }
    }
}
