/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package randomIntegers;

/**
 *
 * @author ett15289
 */
public class randInt26 {
    public int[][] val = new int[26][];
    public int lenVal0;
    public int[] lenVal1 = new int[26];
    public int[][][] swapRuleset = new int[10][][];
    public int lenRuleset0;
    public int[] lenRuleset1 = new int[10];
    public int[][] lenRuleset2 = new int[10][10];
    
    public randInt26(){
        int[] _0 = {24, 11, 25, 23, 6, 25, 17, 11, 3, 13, 25, 20, 16, 22, 18, 1, 3, 2, 5, 13, 22, 22, 16, 0, 14, 3};
        int[] _1 = {19, 20, 9, 5, 1, 3, 7, 2, 23, 21, 22, 22, 15, 10, 13, 2, 20, 20, 20, 4, 25, 2, 21, 22, 12, 10};
        int[] _2 = {13, 1, 14, 5, 21, 20, 11, 10, 17, 22, 0, 11, 23, 23, 8, 10, 24, 0, 17, 20, 25, 0, 5, 12, 9, 24};
        int[] _3 = {3, 24, 16, 12, 2, 18, 6, 25, 20, 14, 24, 14, 19, 25, 6, 21, 1, 22, 20, 9, 19, 22, 4, 20, 1, 23};
        int[] _4 = {9, 0, 3, 9, 9, 13, 10, 8, 24, 14, 19, 9, 7, 16, 23, 16, 23, 5, 10, 24, 20, 6, 22, 14, 17, 16};
        int[] _5 = {17, 15, 3, 16, 3, 3, 20, 8, 12, 19, 19, 20, 1, 19, 11, 13, 1, 5, 20, 20, 5, 14, 5, 17, 6, 13};
        int[] _6 = {1, 4, 12, 23, 10, 17, 16, 24, 18, 0, 17, 19, 0, 4, 24, 25, 9, 21, 9, 15, 22, 7, 16, 22, 20, 5};
        int[] _7 = {7, 25, 11, 16, 7, 22, 7, 3, 25, 23, 12, 4, 23, 23, 22, 22, 9, 22, 25, 14, 5, 8, 14, 4, 3, 3};
        int[] _8 = {15, 11, 24, 2, 2, 11, 0, 17, 18, 9, 5, 16, 14, 0, 4, 25, 0, 3, 7, 20, 5, 20, 0, 16, 23, 16};
        int[] _9 = {5, 12, 3, 5, 16, 3, 17, 6, 12, 10, 5, 12, 14, 12, 22, 11, 17, 11, 0, 2, 16, 20, 23, 6, 13, 20};
        
        int[] _10 = {25, 11, 8, 18, 10, 0, 24, 13, 1, 24, 5, 9, 17, 25, 11, 15, 0, 7, 5, 16, 16, 3, 25, 25, 3, 6};
        int[] _11 = {19, 20, 9, 5, 1, 3, 7, 2, 23, 21, 22, 22, 15, 10, 13, 2, 20, 20, 20, 4, 25, 2, 21, 22, 12, 10};
        int[] _12 = {16, 21, 5, 7, 21, 20, 18, 16, 1, 15, 17, 24, 6, 18, 13, 19, 13, 2, 1, 19, 2, 2, 21, 22, 12, 15};
        int[] _13 = {3, 24, 16, 12, 2, 18, 6, 25, 20, 14, 24, 14, 19, 25, 6, 21, 1, 22, 20, 9, 19, 22, 4, 20, 1, 23};
        int[] _14 = {3, 1, 19, 7, 22, 8, 9, 0, 10, 11, 14, 7, 14, 4, 17, 3, 8, 10, 22, 14, 9, 16, 4, 17, 19, 14};
        int[] _15 = {16, 8, 25, 22, 20, 23, 8, 13, 13, 0, 12, 18, 1, 22, 6, 14, 13, 15, 7, 20, 21, 7, 19, 21, 25, 23};
        int[] _16 = {1, 4, 12, 23, 10, 17, 16, 24, 18, 0, 17, 19, 0, 4, 24, 25, 9, 21, 9, 15, 22, 7, 16, 22, 20, 5};
        int[] _17 = {16, 21, 0, 10, 24, 16, 16, 15, 19, 10, 0, 23, 16, 6, 3, 23, 22, 18, 15, 3, 17, 21, 10, 9, 18, 16};
        int[] _18 = {15, 11, 24, 2, 2, 11, 0, 17, 18, 9, 5, 16, 14, 0, 4, 25, 0, 3, 7, 20, 5, 20, 0, 16, 23, 16};
        int[] _19 = {22, 12, 5, 15, 17, 9, 22, 25, 21, 15, 11, 11, 18, 6, 3, 9, 0, 10, 2, 2, 25, 18, 21, 7, 8, 11};
        
        int[] _20 = {25, 11, 8, 18, 10, 0, 24, 13, 1, 24, 5, 9, 17, 25, 11, 15, 0, 7, 5, 16, 16, 3, 25, 25, 3, 6};
        int[] _21 = {16, 21, 5, 7, 21, 20, 18, 16, 1, 15, 17, 24, 6, 18, 13, 19, 13, 2, 1, 19, 2, 2, 21, 22, 12, 15};
        int[] _22 = {15, 11, 24, 2, 2, 11, 0, 17, 18, 9, 5, 16, 14, 0, 4, 25, 0, 3, 7, 20, 5, 20, 0, 16, 23, 16};
        int[] _23 = {1, 6, 14, 4, 10, 20, 2, 4, 22, 12, 17, 0, 7, 24, 13, 9, 0, 11, 10, 25, 18, 24, 10, 20, 14, 16};
        int[] _24 = {3, 11, 19, 7, 22, 8, 9, 0, 10, 11, 14, 17, 14, 14, 17, 3, 8, 10, 22, 14, 19, 16, 4, 17, 19, 14};
        int[] _25 = {16, 24, 7, 25, 16, 24, 17, 18, 1, 10, 13, 16, 5, 25, 14, 22, 1, 19, 19, 2, 20, 24, 21, 8, 11, 1};
        
        int[][]ruleset0 = {{21, 10}, {9, 20}, {1, 8}, {12, 23}, {4, 12}, {3, 8}, {10, 1}, {23, 4}, {2, 22}, {2, 4}};
        int[][]ruleset1 = {{16, 21}, {16, 14}, {14, 16}, {3, 14}, {9, 22}, {20, 25}, {21, 12}, {1, 4}, {1, 1}, {22, 11}};
        int[][]ruleset2 = {{16, 19}, {11, 12}, {14, 19}, {3, 11}, {13, 3}, {7, 2}, {8, 23}, {20, 13}, {2, 9}, {22, 19}};
        int[][]ruleset3 = {{9, 10}, {8, 18}, {7, 21}, {7, 24}, {7, 13}, {11, 22}, {5, 16}, {20, 17}, {12, 0}, {0, 7}};
        int[][]ruleset4 = {{9, 3}, {12, 20}, {16, 5}, {23, 20}, {9, 21}, {11, 21}, {20, 6}, {10, 24}, {12, 24}, {25, 5}};
        int[][]ruleset5 = {{11, 5}, {19, 17}, {11, 20}, {21, 15}, {21, 15}, {10, 12}, {8, 4}, {0, 17}, {9, 2}, {19, 0}};
        int[][]ruleset6 = {{21, 18}, {13, 11}, {15, 1}, {8, 24}, {17, 3}, {15, 23}, {13, 22}, {11, 14}, {1, 4}, {11, 14}};
        int[][]ruleset7 = {{16, 5}, {7, 3}, {13, 18}, {24, 18}, {10, 22}, {2, 13}, {17, 15}, {3, 6}, {22, 20}, {18, 24}};
        int[][]ruleset8 = {{18, 6}, {2, 0}, {25, 19}, {19, 3}, {10, 6}, {21, 16}, {9, 16}, {24, 0}, {10, 1}, {8, 22}};
        int[][]ruleset9 = {{3, 1}, {11, 3}, {0, 12}, {1, 6}, {11, 12}, {2, 24}, {6, 18}, {11, 0}, {17, 17}, {16, 5}};
        
        this.val[0] = _0;
        this.val[1] = _1;
        this.val[2] = _2;
        this.val[3] = _3;
        this.val[4] = _4;
        this.val[5] = _5;
        this.val[6] = _6;
        this.val[7] = _7;
        this.val[8] = _8;
        this.val[9] = _9;
        this.val[10] = _10;
        this.val[11] = _11;
        this.val[12] = _12;
        this.val[13] = _13;
        this.val[14] = _14;
        this.val[15] = _15;
        this.val[16] = _16;
        this.val[17] = _17;
        this.val[18] = _18;
        this.val[19] = _19;
        this.val[20] = _20;
        this.val[21] = _21;
        this.val[22] = _22;
        this.val[23] = _23;
        this.val[24] = _24;
        this.val[25] = _25;
        this.swapRuleset[0] = ruleset0;
        this.swapRuleset[1] = ruleset1;
        this.swapRuleset[2] = ruleset2;
        this.swapRuleset[3] = ruleset3;
        this.swapRuleset[4] = ruleset4;
        this.swapRuleset[5] = ruleset5;
        this.swapRuleset[6] = ruleset6;
        this.swapRuleset[7] = ruleset7;
        this.swapRuleset[8] = ruleset8;
        this.swapRuleset[9] = ruleset9;
        this.lenVal0 = this.val.length;
        this.getLengths(false);
    }
    
    public void getLengths(boolean in_cmdPrint){
        int i;
        int k;
        String tempStr = "";
        // value matrix lengths
        // value matrix length level 0        
        this.lenVal0 = this.val.length;
        // value matrix length level 1
        for (i = 0; i<=25; i++){
            this.lenVal1[i] = this.val[i].length;
        }
        // swap ruleset matrix lengths
        // swap ruleset matrix length level 0
        this.lenRuleset0 = this.swapRuleset.length;
        // swap ruleset matrix length level 1
        for(i = 0; i<=9; i++){
            this.lenRuleset1[i] = this.swapRuleset[i].length;
        }
        // swap ruleset matrix length level 2
        for(i = 0; i<=9; i++){
            for(k = 0; k<=9; k++){
                this.lenRuleset2[i][k] = this.swapRuleset[i][k].length;
            }            
        }
        if(in_cmdPrint == true){
            System.out.println("lenVal 0: " + this.lenVal0);
            for(i = 0; i<=25; i++){
                tempStr = tempStr + String.valueOf(this.lenVal1[i]) + " ";
            }
            System.out.println("lenVal 1: " + tempStr);
            System.out.println("lenSwap 0: " + this.lenRuleset0);
            tempStr = "";
            for(i = 0; i<=9; i++){
                tempStr = tempStr + String.valueOf(this.lenRuleset1[i]) + " ";
            }
            System.out.println("lenSwap 1: " + tempStr);            
            for(i = 0; i<=9; i++){
                tempStr = "";
                for(k = 0; k<=9; k++){
                    tempStr = tempStr + String.valueOf(this.lenRuleset2[i][k]) + " ";
                }
                System.out.println("lenSwap 2 / " + i + ": " + tempStr);                
            }
        }
    }
    
    public void swapWithRuleset(int in_ruleSetNumber){
        int ruleSetNumber;
        int[] temp1 = new int[10];
        int[] temp2 = new int[10];
        int i;
        //this.printMatrix();
        System.out.println(" ");
        if (in_ruleSetNumber < 0 || in_ruleSetNumber > this.lenRuleset0-1){
            ruleSetNumber = 0;
        }
        else{
            ruleSetNumber = in_ruleSetNumber;
            for(i=0; i<this.lenRuleset1[in_ruleSetNumber]; i++){
                temp1 = this.val[this.swapRuleset[ruleSetNumber][i][0]];
                temp2 = this.val[this.swapRuleset[ruleSetNumber][i][1]];
                this.val[this.swapRuleset[ruleSetNumber][i][0]] = temp2;
                this.val[this.swapRuleset[ruleSetNumber][i][1]] = temp1;
            }
        }
        //this.printMatrix();
    }
    
    public int loopThroughValues(int in_row, int in_column, int in_loopCount){
        int loopCounter = 0;
        int[] coord = {0,0};
        while (loopCounter < in_loopCount){
            if(loopCounter == 0){
                coord[0] = in_row;
                coord[1] = in_column;
            }
            if(coord[0] > this.lenVal0 - 1 || coord[0] < 0){
                coord[0] = 0;
            }
            if(coord[1] > this.lenVal1[coord[0]] - 1 || coord[1] < 0){
                coord[1] = 0;
            }
            coord[1] = this.val[coord[0]][coord[1]];
            coord[0] += 1;
            loopCounter += 1;
        }
        return this.val[coord[0]][coord[1]];
    }
    
    public void printMatrix(){
        for(int i = 0; i< this.lenVal0; i++){
            String temp = "";
            for(int j = 0; j<this.lenVal1[i]; j++){
                temp = temp + this.val[i][j] + " ";
            }
            System.out.println(temp);
        }
    }
}
