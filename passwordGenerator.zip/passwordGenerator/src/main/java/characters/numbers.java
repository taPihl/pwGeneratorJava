/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package characters;

/**
 *
 * @author ett15289
 */
public class numbers {
    public String val;
    public int length;
    
    public numbers(){
        this.val  = "0123456789";
        this.length = this.val.length();
    }
    public int retCharIndex(String in_inputStr){
        int foundIndex;
        foundIndex = this.val.indexOf(in_inputStr);
        return foundIndex;
    }
    public String retString(int in_index){
        String retVal = "";
        int tmpIndex = in_index;
        if(tmpIndex > this.length - 1){
            while(tmpIndex > this.length - 1){
                tmpIndex = tmpIndex / 2;
            }
        }
        retVal = String.valueOf(this.val.charAt(tmpIndex));
        return retVal;
    }  
}
