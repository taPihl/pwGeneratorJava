/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package timers;
import java.util.Date;
/**
 *
 * @author ett15289
 */
public class onDelayTimer {
    Date ms = new Date();
    private long currentTimeMs;
    private long onTimeMs;
    
    public onDelayTimer(long in_delayMs){
        this.currentTimeMs = this.ms.getTime();
        this.onTimeMs = this.currentTimeMs + in_delayMs;
        
        while(this.currentTimeMs < this.onTimeMs){
            Date newMs = new Date();
            this.currentTimeMs = newMs.getTime();

        }        
    }    
}
