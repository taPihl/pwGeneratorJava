/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package create;
import characters.capitalLetters;
import characters.numbers;
import characters.smallLetters;
import characters.specialCharacters;
import config.cfg;
import randomIntegers.randInt10;
import randomIntegers.randInt26;
import timers.onDelayTimer;

/**
 *
 * @author ett15289
 */
public class createPw {
    public String[] pWs = new String[10];
    public int errCode;
    characters.capitalLetters capitals = new characters.capitalLetters();
    characters.numbers numbers = new characters.numbers();
    characters.smallLetters smalls = new characters.smallLetters();
    characters.specialCharacters spcChars = new characters.specialCharacters();
    randomIntegers.randInt10 rnd10 = new randomIntegers.randInt10();
    randomIntegers.randInt26 rnd26 = new randomIntegers.randInt26();
    config.cfg cfg = new config.cfg();
    
    public createPw(){
        for(int i = 0; i<=9; i++){
            this.pWs[i] = "";
        }
        this.errCode = 0;
    }
    
    public boolean checkPw(char[] in_Pw){
        boolean success = true;
        int inStrLen = in_Pw.length;
        int cfgPwLen = this.cfg.createPw.length();
        char inChar;
        char cfgPwChar;
        
        if(inStrLen != cfgPwLen){
            success = false;
        }
        else{
            for(int i = 0; i < inStrLen; i++){
                inChar = in_Pw[i];
                cfgPwChar = this.cfg.createPw.charAt(i);
                if (inChar != cfgPwChar){
                    success = false;
                }
            }
        }
        return success;
    }
    
    public int retCharIndex(String in_char){
        int retVal;
        int temp;
        temp = this.numbers.retCharIndex(in_char);
        if(temp != -1){
           retVal = 100 + temp; 
        }
        else{
           temp = this.smalls.retCharIndex(in_char);
           if(temp != -1){
                retVal = 200 + temp; 
           }
           else{
               temp = this.capitals.retCharIndex(in_char);
               if(temp != -1){
                    retVal = 300 + temp; 
               }
               else{
                   temp = this.spcChars.retCharIndex(in_char);
                   if(temp != -1){
                        retVal = 400 + temp; 
                   }
                   else{
                       retVal = 5;
                   }
               }
           }
        }
        return retVal;
    }
    
    public int retFormatCharType(int in_charIndex){
        String formatChar;
        int retVal = 0;
        formatChar = String.valueOf(this.cfg.format.charAt(in_charIndex));
        retVal = this.retCharIndex(formatChar);
        if (retVal >= 100 && retVal < 200){
            retVal = 1;
        }
        else if(retVal >= 200 && retVal < 300){
            retVal = 2;
        }
        else if(retVal >= 300 && retVal < 400){
            retVal = 3;
        }
        return retVal;
    }
    
public String createSinglePw(int in_pwNumber, String in_decStr){
    int i;
    int decStrLen = in_decStr.length();
    int decIndex;
    int charIndex = 0;
    int formatCharType = 0;
    String nextChar;
    String tempStr = in_decStr;
    String pw = "";
    while(decStrLen < this.cfg.pwLen){
        tempStr = tempStr + in_decStr;
        decStrLen = tempStr.length();        
    }
    //System.out.print(decStrLen);
    for(i = 0; i < this.cfg.pwLen && i < this.cfg.maxLen; i++){

        // get the index of next character in decipher string
        decIndex = this.retCharIndex(String.valueOf(tempStr.charAt(i)));        
        // use characterindex as starting point (row+column) to loop through 26x26 or 10x10 matrix
        if(decIndex < 200){
            if(decIndex >= 100){
                decIndex = decIndex - 100;
            }
            charIndex = rnd10.loopThroughValues(decIndex, decIndex, this.cfg.loopCount);
        }
        else if(decIndex >= 200){
            if(decIndex >= 400){
                decIndex = decIndex - 400;
            }
            else if(decIndex >= 300){
                decIndex = decIndex - 300;
            }
            else if(decIndex >= 200){
                decIndex = decIndex - 200;
            }
            charIndex = rnd26.loopThroughValues(decIndex, decIndex, this.cfg.loopCount * 2);
        }
        // check format string character type
        formatCharType = this.retFormatCharType(i);
        //get next character to password according to generated index and format character type
        switch(formatCharType){
            case 1:
                nextChar = this.numbers.retString(charIndex);
                pw = pw + nextChar;
                break;
            case 2:
                nextChar = this.smalls.retString(charIndex);
                pw = pw + nextChar;
                break;
            case 3:
                nextChar = this.capitals.retString(charIndex);
                pw = pw + nextChar;
                break;
            default:
                nextChar = this.smalls.retString(charIndex);
                pw = pw + nextChar;
                break;
        }
    }
    this.rnd10.swapWithRuleset(in_pwNumber);
    this.rnd26.swapWithRuleset(in_pwNumber);
    return pw;
}

public void printPWs(){
    for(int i = 0; i<this.cfg.pwCount; i++){
        System.out.println(this.cfg.alias[i] + " :" + this.pWs[i]);
    }
}

public void createMain(String in_decStr, char[] in_Pw){

    boolean chckPw = this.checkPw(in_Pw);
    int deStrLen = in_decStr.length();
    if(deStrLen < 1){
        this.errCode = 2; // empty decipher string
    }
    if (chckPw == true && this.errCode == 0){
        for(int i = 0; i<this.cfg.pwCount; i++){
            this.pWs[i] = this.createSinglePw(i, in_decStr);
        }
    }
    else{
        this.errCode = 1; // wrong password
    }
    System.out.println(this.errCode);
}
    
}
